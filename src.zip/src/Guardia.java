
public class Guardia extends Personaje {

	public Guardia() {
		super(20, 1, 3, null, TipoPersonaje.Guardia, null);
	}

}
