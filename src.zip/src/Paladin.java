
public class Paladin extends Personaje {

	public Paladin() {
		super(15, 3, 1, null, TipoPersonaje.Paladin, null);
	}

}