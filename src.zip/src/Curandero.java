
public class Curandero extends Personaje {

	public Curandero() {
		super(15, 2, 2, null, TipoPersonaje.Curandero, null);
	}

}
